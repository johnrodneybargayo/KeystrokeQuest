"use client";

import React from "react";
import Link from "next/link";

const HomePage = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground">
      <header className="text-center">
        <h1 className="text-4xl font-bold mb-4">Welcome to KeyStrokeQuest</h1>
        <p className="text-lg mb-6">
          Test your typing skills, improve your speed, and climb the leaderboard!
        </p>
      </header>

      <div className="flex flex-col md:flex-row items-center gap-4">
        <Link
          href="/typing-test"
          className="px-6 py-3 bg-primary text-white rounded-lg shadow-lg hover:bg-primary-dark"
        >
          Start Typing Test
        </Link>
        <Link
          href="/leaderboard"
          className="px-6 py-3 bg-secondary text-white rounded-lg shadow-lg hover:bg-secondary-dark"
        >
          View Leaderboard
        </Link>
      </div>

      <footer className="mt-10 text-sm">
        <p>
          Built with 💻 by <span className="font-semibold">KeyStrokeQuest Team</span>.
        </p>
      </footer>
    </div>
  );
};

export default HomePage;
