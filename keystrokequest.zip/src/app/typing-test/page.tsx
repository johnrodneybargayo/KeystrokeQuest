import { CodeTypingTest } from '@/components/CodeTypingTest';

export default function TypingTestPage() {
  return <CodeTypingTest />;
}
