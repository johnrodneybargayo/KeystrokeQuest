import React, { useEffect, useState } from "react";
import { database } from "@/services/firebase";
import { ref, onValue } from "firebase/database";

interface LeaderboardEntry {
  username: string;
  wpm: number;
}

const Leaderboard: React.FC = () => {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    const leaderboardRef = ref(database, "leaderboard");
    onValue(leaderboardRef, (snapshot) => {
      const data = snapshot.val() || {};
      const entries = Object.values(data) as LeaderboardEntry[];
      setLeaderboard(entries.sort((a, b) => b.wpm - a.wpm));
    });
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-lg font-bold mb-4">Leaderboard</h2>
      <ul>
        {leaderboard.map((entry, index) => (
          <li key={index}>
            {index + 1}. {entry.username} - {entry.wpm} WPM
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Leaderboard;
