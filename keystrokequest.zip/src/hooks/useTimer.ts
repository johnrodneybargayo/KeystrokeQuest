import { useState, useEffect, useCallback } from 'react';

export function useTimer(initialDuration: number) {
  const [timeLeft, setTimeLeft] = useState(initialDuration);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout | undefined;

    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    } else if (timeLeft <= 0) {
      setIsRunning(false);
    }

    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isRunning, timeLeft]);

  const startTimer = useCallback(() => {
    if (!isRunning) setIsRunning(true);
  }, [isRunning]);

  const resetTimer = useCallback(() => {
    setIsRunning(false);
    setTimeLeft(initialDuration);
  }, [initialDuration]);

  const updateDuration = useCallback(
    (newDuration: number) => {
      setTimeLeft(newDuration);
      if (!isRunning) setIsRunning(false);
    },
    [isRunning]
  );

  return {
    timeLeft,
    resetTimer,
    startTimer,
    updateDuration,
  };
}
